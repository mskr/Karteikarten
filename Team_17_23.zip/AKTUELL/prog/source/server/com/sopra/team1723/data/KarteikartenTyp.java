package com.sopra.team1723.data;

/**
 * 
 */
public enum KarteikartenTyp {
    BILD,
    TEXT,
    VIDEO
}