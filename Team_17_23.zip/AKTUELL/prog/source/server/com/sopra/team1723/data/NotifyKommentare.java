package com.sopra.team1723.data;

/**
 * 
 */
public enum NotifyKommentare {
    KEINE,
    VERANSTALTUNG_TEILGENOMMEN,
    DISKUSSION_TEILGENOMMEN
}