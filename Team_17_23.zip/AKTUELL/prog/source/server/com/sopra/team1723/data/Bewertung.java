package com.sopra.team1723.data;

import java.util.*;

/**
 * 
 */
public class Bewertung {

    /**
     * 
     */
    public Bewertung() {
    }

    /**
     * 
     */
    private int id;

    /**
     * 
     */
    private Date erstelldatum;

    /**
     * 
     */
    private int bewertung;

    /**
     * 
     */
    private int erstellerID;

    /**
     * 
     */
    private int kommentarID;

}