package com.sopra.team1723.exceptions;


/**
  Wenn es in der Datenbank keinen Benutzer mit der angegebenen eMail und Passwort gibt, wird diese Exception geworfen.
 */
public class DbFalseLoginDataException extends Exception
{

}
