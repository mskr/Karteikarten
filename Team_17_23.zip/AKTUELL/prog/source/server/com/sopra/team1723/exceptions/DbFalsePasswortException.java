package com.sopra.team1723.exceptions;


public class DbFalsePasswortException extends Exception
{

}
