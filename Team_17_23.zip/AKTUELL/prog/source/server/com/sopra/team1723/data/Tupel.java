package com.sopra.team1723.data;

public class Tupel<X, Y> { 
    public final X x; 
    public final Y y; 
    public Tupel(X x, Y y) { 
      this.x = x; 
      this.y = y; 
    } 
  } 
