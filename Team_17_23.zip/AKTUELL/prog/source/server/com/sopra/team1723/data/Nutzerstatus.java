package com.sopra.team1723.data;

/**
 * 
 */
public enum Nutzerstatus {
    STUDENT,
    DOZENT,
    ADMIN;
}