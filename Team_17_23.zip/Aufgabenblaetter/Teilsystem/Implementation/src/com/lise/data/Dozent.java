package com.lise.data;

public class Dozent extends Benutzer{
	
	public Dozent(){
		super();
		this.setNutzerstatus(eNutzerstatus.Dozent);
	}
	
	
	
}