Anleitung um das Projekt in Eclipse zu importieren.
1. Neues "Dynamic Web Page" - Projekt anlegen.
2. Rechtsklick auf den Projektnamen links.
3. Klick auf "Import".
4. "File System" auswählen und weiter.
5. Dateipfad zum "Implementation"-Ordner wählen.
6. Den Haken beim "Implementation"-Ordner setzen.
7. Unten auf "Advanced" klicken.
8. Im aufgetauchten Bereich ALLE Haken setzen. Die Dateien werden jetzt als Verweis im Projekt gespeichert.


Diese Schritte immer wiederholen, wenn neue Ordner oder neue Dateien hinzugefügt werden. Wenn eine Fehlermeldung beim letzten Schritt auftritt, einfach auf "No to All" klicken. (Schon importierte Dateien müssen nicht nochmal importiert werden.)

.

